#ifndef DECOMPRESS_H
#define DECOMPRESS_H

void decompress(void *mio0, void *dest);

#endif // DECOMPRESS_H
